<?php
session_start();

// Redirect to login if the user is not logged in
if (empty($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chess Game</title>
    <!-- Chessboard.js CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/chessboard-js/1.0.0/chessboard-1.0.0.min.css">
    <style>
        body {
            text-align: center;
            background: linear-gradient(135deg, #66785F, white);
            background-attachment: fixed;
            color: white;
            font-family: Arial, sans-serif;
        }
        #chessboard {
            width: 400px;
            margin: 20px auto;
        }
        .logout-button {
            position: absolute;
            top: 10px;
            right: 10px;
            padding: 10px 20px;
            background: #4B5945;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        .logout-button:hover {
            background: #66785F;
        }
    </style>
</head>
<body>
    <!-- Logout Button -->
    <form action="logout.php" method="POST">
        <button type="submit" class="logout-button">Logout</button>
    </form>

    <h1>Chess Game</h1>
    <div id="chessboard"></div>
    <p id="status">Make your move!</p>

    <!-- Chessboard.js JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/chessboard-js/1.0.0/chessboard-1.0.0.min.js"></script>
    <!-- Chess.js for move validation -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/chess.js/0.10.2/chess.min.js"></script>
    <!-- Stockfish Web Worker -->
    <script>
        // Initialize the chessboard
        const board = Chessboard('chessboard', {
            draggable: true,
            position: 'start',
            onDrop: handleMove,
        });

        // Initialize the chess game
        const game = new Chess();

        // Initialize Stockfish
        const stockfish = new Worker('chess/stockfish.js'); // Update this path
        stockfish.onmessage = handleEngineResponse;

        // Handle user moves
        function handleMove(source, target) {
            const move = game.move({ from: source, to: target, promotion: 'q' }); // Always promote to queen for simplicity

            if (move === null) {
                return 'snapback'; // Illegal move
            }

            updateStatus();
            stockfish.postMessage(`position fen ${game.fen()}`);
            stockfish.postMessage('go depth 15'); // Let Stockfish calculate its move
        }

        // Handle Stockfish's response
        function handleEngineResponse(event) {
            const response = event.data;

            if (response.startsWith('bestmove')) {
                const bestMove = response.split(' ')[1];
                game.move(bestMove);
                board.position(game.fen());
                updateStatus();
            }
        }

        // Update the game status
        function updateStatus() {
            let status = '';

            if (game.in_checkmate()) {
                status = 'Game over, checkmate!';
            } else if (game.in_draw()) {
                status = 'Game over, draw!';
            } else {
                status = game.turn() === 'w' ? 'White to move' : 'Black to move';
                if (game.in_check()) {
                    status += ', check!';
                }
            }

            document.getElementById('status').textContent = status;
        }

        // Start the game
        updateStatus();
    </script>
</body>
</html>